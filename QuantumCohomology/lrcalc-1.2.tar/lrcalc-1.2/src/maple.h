#ifndef _MAPLE_H
#define _MAPLE_H

void maple_print_lincomb(hashtab *ht, char *letter, int nl);

#endif
